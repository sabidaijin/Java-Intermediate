public abstract class Customer extends User {
	int point;
	
	public abstract void purchase(String itemID, int num); 
}
